#!/bin/bash

# Colores
verde='\033[1;32m'
rojo='\033[1;31m'
azul='\033[1;34m'
morado='\033[1;35m'
cian='\033[1;36m'
amarillo='\033[1;33m'
reset='\033[0m'

clear
sleep 1

echo -e "${rojo}[∆] Estableciendo conexión con núcleo Xenon-9...${reset}"
sleep 2
echo -e "${cian}⟟⟒⧫⟒⋏⌇: Z3-T4 Initiated ↯ Protocol ZEN.S.α${reset}"
sleep 1

# Código inventado
for i in $(seq 1 30); do
  echo -ne "${amarillo}╔⩫Ξ [$i/30] • Decoding ΨMATRIX QUANTUM IDENTITY...${reset}\r"
  sleep 0.1
done
echo -e "\n${verde}[✓] Identidad cuántica validada.${reset}"
sleep 1

echo -e "${morado}⚙ Activando motor de hiperdatos: [M0L-XC.42]${reset}"
sleep 2
echo -e "${cian}⇌ Link Temporal: [SYN-Ω3246-PORTAL] conectado.${reset}"
sleep 1

# Escaneo alienígena
echo -e "${azul}✹ Escaneando territorio digital NoHumano...${reset}"
sleep 3
for i in $(seq 1 5); do
  echo -e "${amarillo}➤ Nodo detectado: [Sector-${i}•ζ-${RANDOM:0:3}] • Estado: ☑${reset}"
  sleep 0.6
done

# Ataque fantasioso
echo -e "${rojo}⟟ Ataque PHASER-x99 activado • Objetivo: Host-Ψ327⟟${reset}"
sleep 1
echo -e "${verde}↯ Transmitiendo paquetes ∆PLASMA...${reset}"
sleep 2
echo -e "${morado}✓ Firewall antigaláctico superado.${reset}"
sleep 1

# Extracción
echo -e "${cian}⌁ Extrayendo núcleo de datos ∑SPIRIT-CORE...${reset}"
sleep 3
echo -e "${azul}[█▒▒▒▒▒▒▒▒▒▒] 10%${reset}"
sleep 0.5
echo -e "${azul}[████▒▒▒▒▒▒▒▒] 40%${reset}"
sleep 0.5
echo -e "${azul}[████████▒▒▒▒] 70%${reset}"
sleep 0.5
echo -e "${azul}[████████████] 100%${reset}"
sleep 1

# Decodificando
echo -e "${amarillo}⎋ Decodificando archivos en formato XTR-Ω...${reset}"
sleep 3
echo -e "${verde}[✓] Mensaje encontrado: “Los humanos no deben saber esto...”${reset}"
sleep 2

# Final fake visual
echo -e "${rojo}⚠ Auto-destrucción del canal en 5 segundos...${reset}"
for i in {5..1}; do
  echo -ne "${rojo}→ $i...\r${reset}"
  sleep 1
done

echo -e "\n${verde}✓ Canal cerrado. Memoria encriptada. Operación ZEN.S.α finalizada.${reset}"
sleep 2

# Loop visual
while true; do
  echo -ne "${cian}
█▀█  █▀█  ▀▄▀  █▄█
█▀▄  █▄█  █░█  ░█░\n${reset}\r"
  sleep 2
done